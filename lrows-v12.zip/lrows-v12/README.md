# Discord Register Bot


 - [Discord Register Bot](https://github.com/UtkuJS/100-Komutlu-V12-Bot)
      - [Kurulum](#kurulum)
      - [İçerikler](#İçerikler)
      - [İletişim](#İletişim)
      - [FAQ](#faq)

<div align="center">
   <a href="https://github.com/BetaWile">
      <img src="https://betaaa.has-a-hot.mom/55orRHk8J.gif">
   </a>
</div>

# Kurulum
* İlk olarak bilgisayarına [Node JS](https://nodejs.org/en/) indir.
* Bu projeyi zip halinde indir.
* Herhangi bir klasöre zipi çıkart.
* Daha sonra `src`dosyasındaki `Settings` dosyasının içindeki `Config.json`, `Settings.json` dosyalardaki bilgileri doldur.
* Sonra klasörün içerisinde bir `powershell` ya da `cmd` penceresi aç.
* ```npm install``` yazarak tüm modülleri kur.
* Kurulum bittikten sonra ```node beta.js``` yaz ve botu başlat.


## Botun İntentlerini Açmayı Unutma!
* [Açmak İçin Tıkla](https://discord.com/developers/applications)
<img src="https://cdn.discordapp.com/attachments/818953120452575322/851116463166849054/3P4KKB.png"/>

***Tadaaa 🎉. Artık register botun hazır. Dilediğin gibi kullanabilirsin.***

# İletişim
* [Discord Profilim](https://discord.com/users/236173144300191754)
* [Discord Sunucum](botclub.net/davet)

# FAQ
Sıkça sorulan sorulara buradan ulaşabilirsin.

**Q:** Altyapıyı geliştirilmeye devam edilecek mi?<br />
**A:** Eğer bir şeyler eklersem dolaylı yoldan burayada ekleyeceğim.

**Q:** İstek herhangi bir şey ekliyor musun?<br />
**A:** Eğer istediğin şey hoşuma giderse ve yapmaktan zevk alacaksam eklerim.

**Q:** Altyapı tamamen sanamı ait?<br />
**A:** Hayır, tamamen bana ait değil sadece bağzı yapamadığım ufak bir kısmıları hazır olarak ekledim.  

**Q:** Hatalarla ilgileniyor musun?<br />
**A:** Proje içindeki hatalarla ilgileniyorum. Eğer bir hata ile karşılaşırsanız lütfen Discorddan benimle iletişim kurun. 


## NOT: Botta MIT lisansı bulunmaktadır. Bu botun dosyalarının benden habersiz paylaşılması/satılması durumunda gerekli işlemler yapılacaktır!
